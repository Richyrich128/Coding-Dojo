function remove(word) {
    word.remove();
}
function logout(element) {
    element.innerText = "Logout"
}